# Dose — Coffee Efficiency Dashboard

Track coffee and milk efficiency for your coffee shop by comparing Square POS sales against stock deliveries.

## Setup

### Railway Environment Variables
Set these in your Railway service → Variables tab:

| Variable | Description |
|---|---|
| `SQUARE_ACCESS_TOKEN` | Your Square production access token (starts with EAAA) |
| `NODE_ENV` | Set to `production` |

### Deploy
1. Push this repo to GitHub
2. Create a new Railway project → Deploy from GitHub repo
3. Add the environment variables above
4. Railway auto-builds and deploys

## How it works

- **Dashboard** — select a date range or delivery cycle, click Run Report to pull live Square data
- **Drink Recipes** — maps Square item names to coffee pool and gram dose. Pre-seeded with your menu on first run.
- **Stock Log** — log coffee deliveries (per pool) and milk deliveries / Numilk batches
- **Settings** — set Square Location ID (optional), configure ml-per-modifier for milk tracking

## Milk tracking
Milk consumption is calculated from Square modifier counts (Whole / Oat / Almond), not recipe definitions. Configure ml-per-modifier in Stock Log (default 180ml).

## Coffee pools
| Pool | Items |
|---|---|
| Espresso | All espresso-based drinks |
| Drip | Batch Brew, Cafe Au Lait |
| Cold Brew | Cold Brew |
| Pour-Over | Pour Over (all beans), Turkish Coffee |

## Dose calculations
- **Drip**: 24.4g per cup (110g ÷ 4.5 cups per batch)
- **Cold Brew**: 26.2g per serve (4kg ÷ 152.5 serves from 20×1.8L bottles)
- **Pour-Over**: 19g per single brew
- **Turkish**: 7.5g, deducted from pour-over pool
