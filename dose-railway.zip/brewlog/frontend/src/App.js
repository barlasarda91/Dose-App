import React, { useState } from 'react';
import './App.css';
import Dashboard from './pages/Dashboard';
import Stock     from './pages/Stock';
import Recipes   from './pages/Recipes';
import Settings  from './pages/Settings';

export default function App() {
  const [page, setPage] = useState('dashboard');
  const pages = [
    { id: 'dashboard', label: 'Dashboard' },
    { id: 'stock',     label: 'Stock' },
    { id: 'recipes',   label: 'Recipes' },
    { id: 'settings',  label: 'Settings' },
  ];
  return (
    <>
      <nav className="nav">
        <span className="nav-logo">Dose · Boxx Coffee Roasters Co.</span>
        <ul className="nav-links">
          {pages.map(p => (
            <li key={p.id}>
              <span className={`nav-link${page === p.id ? ' active' : ''}`} onClick={() => setPage(p.id)}>
                {p.label}
              </span>
            </li>
          ))}
        </ul>
      </nav>
      {page === 'dashboard' && <Dashboard />}
      {page === 'stock'     && <Stock />}
      {page === 'recipes'   && <Recipes />}
      {page === 'settings'  && <Settings />}
    </>
  );
}
