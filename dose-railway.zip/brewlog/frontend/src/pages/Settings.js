import React, { useState, useEffect } from 'react';

export default function Settings({ onSave }) {
  const [locationId, setLocationId] = useState('');
  const [tokenSet, setTokenSet]     = useState(false);
  const [saved, setSaved]           = useState(false);

  useEffect(() => {
    fetch('/api/settings').then(r => r.json()).then(s => {
      setLocationId(s.square_location_id || '');
      setTokenSet(!!s.square_token_set);
    });
  }, []);

  async function save() {
    await fetch('/api/settings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ square_location_id: locationId }),
    });
    setSaved(true);
    if (onSave) onSave();
    setTimeout(() => setSaved(false), 2500);
  }

  return (
    <div className="page">
      <div className="page-eyebrow">Configuration</div>
      <h1 className="page-title">Settings</h1>
      <p className="page-sub">Square API, milk rates, and dose reference.</p>
      <hr className="page-rule" />

      <div className="settings-section">
        <div className="section-title">Square API</div>
        <div className="settings-card">
          <div className="settings-field">
            <label className="settings-field-lbl">Access Token</label>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginTop: 4 }}>
              <span className={`conn-status ${tokenSet ? 'ok' : 'fail'}`} style={{ marginTop: 0 }}>
                {tokenSet ? '● Token configured via Railway environment variable' : '✕ SQUARE_ACCESS_TOKEN not set — add it as a Railway environment variable'}
              </span>
            </div>
            <div className="settings-field-hint" style={{ marginTop: 8 }}>
              Set <code>SQUARE_ACCESS_TOKEN</code> in your Railway service → Variables tab. The token never passes through the browser.
            </div>
          </div>

          <div className="settings-field">
            <label className="settings-field-lbl">Location ID <span style={{ fontWeight: 300, textTransform: 'none', letterSpacing: 0 }}>(optional)</span></label>
            <input type="text" placeholder="L1234ABCD…" value={locationId} onChange={e => setLocationId(e.target.value)} style={{ maxWidth: 320 }} />
            <div className="settings-field-hint">Leave blank to query all locations.</div>
          </div>

          <div style={{ display: 'flex', gap: 10, marginTop: 8 }}>
            <button className="btn btn-primary" onClick={save}>Save</button>
            {saved && <span className="conn-status ok" style={{ marginTop: 0 }}>✓ Saved</span>}
          </div>
        </div>
      </div>

      <div className="settings-section">
        <div className="section-title">Dose Reference</div>
        <div className="settings-card">
          <p style={{ fontSize: 12, color: 'var(--steam)', marginBottom: 16, lineHeight: 1.7 }}>
            Fixed dose calculations baked into your drink recipes. Edit on the Drink Recipes page to adjust.
          </p>
          <div className="table-wrap">
            <table>
              <thead><tr><th>Pool</th><th>Drink</th><th>Dose</th><th>Calculation</th></tr></thead>
              <tbody>
                <tr><td>Espresso</td><td>All espresso drinks</td><td style={{ fontFamily: 'DM Mono' }}>18g</td><td style={{ color: 'var(--steam)' }}>Single shot</td></tr>
                <tr><td>Drip</td><td>Batch Brew, Cafe Au Lait</td><td style={{ fontFamily: 'DM Mono' }}>24.4g</td><td style={{ color: 'var(--steam)' }}>110g ÷ 4.5 cups per batch</td></tr>
                <tr><td>Cold Brew</td><td>Cold Brew</td><td style={{ fontFamily: 'DM Mono' }}>26.2g</td><td style={{ color: 'var(--steam)' }}>4kg ÷ (20×1.8L ÷ 236ml per 8oz serve)</td></tr>
                <tr><td>Pour-Over</td><td>Pour Over (all beans)</td><td style={{ fontFamily: 'DM Mono' }}>19g</td><td style={{ color: 'var(--steam)' }}>Single brew</td></tr>
                <tr><td>Pour-Over</td><td>Turkish Coffee</td><td style={{ fontFamily: 'DM Mono' }}>7.5g</td><td style={{ color: 'var(--steam)' }}>Shares pour-over pool</td></tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
