require('dotenv').config();
const express = require('express');
const cors = require('cors');
const fetch = require('node-fetch');
const Database = require('better-sqlite3');
const path = require('path');
const { generateReport } = require('./report');

const app = express();
app.use(cors());
app.use(express.json());

const LBS_TO_GRAMS = 453.592;
const GALLONS_TO_ML = 3785.41;

const dbPath = process.env.DB_PATH || '/app/data/dose.db';
require('fs').mkdirSync(require('path').dirname(dbPath), { recursive: true });
const db = new Database(dbPath);

db.exec(`
  CREATE TABLE IF NOT EXISTS drink_recipes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    square_item_name TEXT NOT NULL,
    category TEXT NOT NULL CHECK(category IN ('espresso','drip','coldbrew','pourover')),
    coffee_grams REAL NOT NULL,
    milk_whole_ml REAL DEFAULT 0,
    notes TEXT,
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS coffee_deliveries (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    delivery_date TEXT NOT NULL,
    espresso_lbs_received REAL DEFAULT 0,
    espresso_lbs_onhand  REAL DEFAULT 0,
    drip_lbs_received    REAL DEFAULT 0,
    drip_lbs_onhand      REAL DEFAULT 0,
    coldbrew_lbs_received REAL DEFAULT 0,
    coldbrew_lbs_onhand  REAL DEFAULT 0,
    pourover_lbs_received REAL DEFAULT 0,
    pourover_lbs_onhand  REAL DEFAULT 0,
    notes TEXT,
    created_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS milk_deliveries (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    delivery_date TEXT NOT NULL,
    whole_bottles_received REAL DEFAULT 0,
    whole_bottles_onhand   REAL DEFAULT 0,
    notes TEXT,
    created_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
  );

  INSERT OR IGNORE INTO settings (key, value) VALUES ('alt_milk_ml_per_modifier', '180');
  INSERT OR IGNORE INTO settings (key, value) VALUES ('square_location_id', '');
  INSERT OR IGNORE INTO settings (key, value) VALUES ('numilk_oat_liters_per_day', '0');
  INSERT OR IGNORE INTO settings (key, value) VALUES ('numilk_almond_liters_per_day', '0');
`);

// ─── Settings ─────────────────────────────────────────────────────────────────
app.get('/api/settings', (req, res) => {
  const rows = db.prepare('SELECT key, value FROM settings').all();
  const s = {};
  for (const r of rows) s[r.key] = r.value;
  s.square_token_set = !!process.env.SQUARE_ACCESS_TOKEN;
  res.json(s);
});

app.post('/api/settings', (req, res) => {
  const allowed = ['alt_milk_ml_per_modifier', 'square_location_id', 'numilk_oat_liters_per_day', 'numilk_almond_liters_per_day'];
  for (const key of allowed) {
    if (req.body[key] !== undefined)
      db.prepare('INSERT OR REPLACE INTO settings (key, value) VALUES (?,?)').run(key, String(req.body[key]));
  }
  res.json({ success: true });
});

// ─── Square helpers ───────────────────────────────────────────────────────────
async function getLocationIds() {
  const res = await fetch('https://connect.squareup.com/v2/locations', {
    headers: { 'Authorization': `Bearer ${process.env.SQUARE_ACCESS_TOKEN}`, 'Square-Version': '2024-01-17' }
  });
  const data = await res.json();
  if (data.errors) throw new Error(data.errors[0]?.detail || 'Failed to fetch locations');
  return (data.locations || []).filter(l => l.status === 'ACTIVE').map(l => l.id);
}

async function squarePost(endpoint, body) {
  const token = process.env.SQUARE_ACCESS_TOKEN;
  if (!token) throw new Error('SQUARE_ACCESS_TOKEN not configured');
  const res = await fetch(`https://connect.squareup.com/v2${endpoint}`, {
    method: 'POST',
    headers: { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json', 'Square-Version': '2024-01-17' },
    body: JSON.stringify(body),
  });
  return res.json();
}

async function fetchAllOrders(startDate, endDate, locationIds) {
  if (!locationIds || locationIds.length === 0) locationIds = await getLocationIds();
  const all = [];
  let cursor = null;
  do {
    const body = {
      location_ids: locationIds,
      query: {
        filter: {
          date_time_filter: { created_at: { start_at: `${startDate}T00:00:00.000Z`, end_at: `${endDate}T23:59:59.999Z` } },
          state_filter: { states: ['COMPLETED'] },
        },
      },
      limit: 500,
    };
    if (cursor) body.cursor = cursor;
    const data = await squarePost('/orders/search', body);
    if (data.errors) throw new Error(data.errors[0]?.detail || 'Square API error');
    all.push(...(data.orders || []));
    cursor = data.cursor || null;
  } while (cursor);
  return all;
}

function aggregateOrders(orders) {
  const itemCounts = {};
  // itemMilk tracks per-item modifier counts: { 'Caffe Latte': { whole: 12, oat: 8, almond: 3 } }
  const itemMilk = {};
  const mods = { milk_whole: 0, milk_oat: 0, milk_almond: 0 };
  for (const order of orders) {
    for (const item of (order.line_items || [])) {
      const name = item.name || 'Unknown';
      const qty = parseInt(item.quantity || '1', 10);
      itemCounts[name] = (itemCounts[name] || 0) + qty;
      if (!itemMilk[name]) itemMilk[name] = { whole: 0, oat: 0, almond: 0 };
      for (const mod of (item.modifiers || [])) {
        const n = (mod.name || '').toLowerCase().trim();
        if (n === 'whole')  { mods.milk_whole  += qty; itemMilk[name].whole  += qty; }
        if (n === 'oat')    { mods.milk_oat    += qty; itemMilk[name].oat    += qty; }
        if (n === 'almond') { mods.milk_almond += qty; itemMilk[name].almond += qty; }
      }
    }
  }
  return {
    orders: Object.entries(itemCounts).map(([name, qty]) => ({
      name, qty,
      milk: itemMilk[name] || { whole: 0, oat: 0, almond: 0 }
    })),
    modifiers: mods,
  };
}

// ─── Analytics ────────────────────────────────────────────────────────────────
// Efficiency logic:
//
// CLOSED cycle (delivery B exists AFTER the period end):
//   opening_stock  = on_hand_A + received_A (first delivery in/before period)
//   theoretical_remaining = opening_stock - theoretical_use
//   actual_remaining      = on_hand at first delivery AFTER period end
//   waste                 = theoretical_remaining - actual_remaining  (if > 0)
//   efficiency flagged as WASTE only when actual < theoretical
//
// OPEN cycle (no closing delivery yet):
//   Show theoretical use vs stock, no waste flag — cycle not closed
//
// Numilk: daily_rate × days, no closing count available

app.post('/api/analytics', async (req, res) => {
  try {
    const { start_date, end_date } = req.body;
    if (!start_date || !end_date) return res.status(400).json({ error: 'start_date and end_date required' });

    const cfg = {};
    for (const r of db.prepare('SELECT key, value FROM settings').all()) cfg[r.key] = r.value;
    const mlPerMod = parseFloat(cfg.alt_milk_ml_per_modifier) || 180;
    const locationIds = cfg.square_location_id ? [cfg.square_location_id] : [];
    const oatLitersPerDay    = parseFloat(cfg.numilk_oat_liters_per_day)    || 0;
    const almondLitersPerDay = parseFloat(cfg.numilk_almond_liters_per_day) || 0;

    // Days in period (inclusive)
    const msPerDay = 86400000;
    const days = Math.round((new Date(end_date) - new Date(start_date)) / msPerDay) + 1;

    // Square orders
    const rawOrders = await fetchAllOrders(start_date, end_date, locationIds);
    const { orders: itemList, modifiers } = aggregateOrders(rawOrders);

    // Recipe matching
    const recipes = db.prepare('SELECT * FROM drink_recipes').all();
    const recipeMap = {};
    for (const r of recipes) recipeMap[r.square_item_name.toLowerCase().trim()] = r;

    const coffeeUsed = { espresso: 0, drip: 0, coldbrew: 0, pourover: 0 };
    const matched = {}, unmatched = {};
    for (const { name, qty, milk } of itemList) {
      const r = recipeMap[name.toLowerCase().trim()];
      if (r) {
        coffeeUsed[r.category] += r.coffee_grams * qty;
        matched[name] = { qty: (matched[name]?.qty || 0) + qty, milk };
      } else {
        unmatched[name] = (unmatched[name] || 0) + qty;
      }
    }

    // Milk used from modifiers
    const milkUsed = {
      whole:  modifiers.milk_whole  * mlPerMod,
      oat:    modifiers.milk_oat    * mlPerMod,
      almond: modifiers.milk_almond * mlPerMod,
    };

    // Coffee deliveries in period, sorted oldest first
    const coffeeDels = db.prepare(
      'SELECT * FROM coffee_deliveries WHERE delivery_date >= ? AND delivery_date <= ? ORDER BY delivery_date ASC'
    ).all(start_date, end_date);

    // Closing delivery = first delivery STRICTLY after end_date (gives us actual on_hand)
    const closingCoffeeDel = db.prepare(
      'SELECT * FROM coffee_deliveries WHERE delivery_date > ? ORDER BY delivery_date ASC LIMIT 1'
    ).get(end_date);

    const closingMilkDel = db.prepare(
      'SELECT * FROM milk_deliveries WHERE delivery_date > ? ORDER BY delivery_date ASC LIMIT 1'
    ).get(end_date);

    // Opening stock per pool: on_hand + received at first delivery, lbs → grams
    function calcCoffeeStock(dels, receivedField, onhandField) {
      if (dels.length === 0) return 0;
      const first = dels[0];
      let stock = (first[onhandField] + first[receivedField]) * LBS_TO_GRAMS;
      for (let i = 1; i < dels.length; i++) stock += dels[i][receivedField] * LBS_TO_GRAMS;
      return stock;
    }

    const stock = {
      espresso: calcCoffeeStock(coffeeDels, 'espresso_lbs_received', 'espresso_lbs_onhand'),
      drip:     calcCoffeeStock(coffeeDels, 'drip_lbs_received',     'drip_lbs_onhand'),
      coldbrew: calcCoffeeStock(coffeeDels, 'coldbrew_lbs_received', 'coldbrew_lbs_onhand'),
      pourover: calcCoffeeStock(coffeeDels, 'pourover_lbs_received', 'pourover_lbs_onhand'),
    };

    // Whole milk stock (gallons → ml)
    const milkDels = db.prepare(
      'SELECT * FROM milk_deliveries WHERE delivery_date >= ? AND delivery_date <= ? ORDER BY delivery_date ASC'
    ).all(start_date, end_date);

    let milkWholeStock = 0;
    if (milkDels.length > 0) {
      const first = milkDels[0];
      milkWholeStock = (first.whole_bottles_onhand + first.whole_bottles_received) * GALLONS_TO_ML;
      for (let i = 1; i < milkDels.length; i++) milkWholeStock += milkDels[i].whole_bottles_received * GALLONS_TO_ML;
    }

    // Numilk stock = daily rate × days in period
    const milkOatStock    = oatLitersPerDay    * days * 1000;
    const milkAlmondStock = almondLitersPerDay * days * 1000;

    // Actual remaining from closing delivery on_hand (null if cycle still open)
    const actualRemaining = {
      espresso: closingCoffeeDel ? closingCoffeeDel.espresso_lbs_onhand * LBS_TO_GRAMS : null,
      drip:     closingCoffeeDel ? closingCoffeeDel.drip_lbs_onhand     * LBS_TO_GRAMS : null,
      coldbrew: closingCoffeeDel ? closingCoffeeDel.coldbrew_lbs_onhand * LBS_TO_GRAMS : null,
      pourover: closingCoffeeDel ? closingCoffeeDel.pourover_lbs_onhand * LBS_TO_GRAMS : null,
      milk_whole: closingMilkDel ? closingMilkDel.whole_bottles_onhand * GALLONS_TO_ML : null,
    };

    const cycleOpen = !closingCoffeeDel;

    // Efficiency function
    // If cycle is closed: compare theoretical remaining vs actual remaining (on_hand at next delivery)
    // If cycle is open: show theoretical use vs stock, no waste flag
    function eff(stocked, usedRaw, actualRem) {
      const used = Math.round(usedRaw * 10) / 10;
      if (!stocked) return { stocked: 0, used, efficiency_pct: null, remaining: null, actual_remaining: null, flag: used > 0 ? 'NO_STOCK_LOGGED' : null, cycle_open: cycleOpen };
      const theoreticalRem = stocked - used;
      const pct = Math.round((used / stocked) * 1000) / 10;
      let flag = null;
      let waste = null;
      if (used > stocked) {
        flag = 'OVER_EXPECTED';
      } else if (!cycleOpen && actualRem !== null) {
        // Cycle closed: real waste = theoretical remaining - actual remaining
        waste = theoreticalRem - actualRem;
        if (waste > stocked * 0.05) flag = 'WASTE';
      }
      return {
        stocked: Math.round(stocked * 10) / 10,
        used,
        efficiency_pct: pct,
        theoretical_remaining: Math.round(theoreticalRem * 10) / 10,
        actual_remaining: actualRem !== null ? Math.round(actualRem * 10) / 10 : null,
        waste: waste !== null ? Math.round(waste * 10) / 10 : null,
        flag,
        cycle_open: cycleOpen,
      };
    }

    res.json({
      period: { start_date, end_date, days },
      total_orders: itemList.reduce((s, o) => s + o.qty, 0),
      matched, unmatched,
      modifier_counts: modifiers,
      milk_used: milkUsed,
      numilk_produced: {
        oat_ml:    milkOatStock,
        almond_ml: milkAlmondStock,
        days,
        oat_liters_per_day:    oatLitersPerDay,
        almond_liters_per_day: almondLitersPerDay,
      },
      cycle_open: cycleOpen,
      closing_delivery_date: closingCoffeeDel?.delivery_date || null,
      eff: {
        espresso:    eff(stock.espresso,    coffeeUsed.espresso,  actualRemaining.espresso),
        drip:        eff(stock.drip,        coffeeUsed.drip,      actualRemaining.drip),
        coldbrew:    eff(stock.coldbrew,    coffeeUsed.coldbrew,  actualRemaining.coldbrew),
        pourover:    eff(stock.pourover,    coffeeUsed.pourover,  actualRemaining.pourover),
        milk_whole:  eff(milkWholeStock,    milkUsed.whole,       actualRemaining.milk_whole),
        milk_oat:    eff(milkOatStock,      milkUsed.oat,         null),
        milk_almond: eff(milkAlmondStock,   milkUsed.almond,      null),
      },
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

// ─── Recipes CRUD ─────────────────────────────────────────────────────────────
app.get('/api/recipes', (req, res) => res.json(db.prepare('SELECT * FROM drink_recipes ORDER BY category, square_item_name').all()));

app.post('/api/recipes', (req, res) => {
  const { square_item_name, category, coffee_grams, milk_whole_ml, notes } = req.body;
  const r = db.prepare('INSERT INTO drink_recipes (square_item_name,category,coffee_grams,milk_whole_ml,notes) VALUES (?,?,?,?,?)')
    .run(square_item_name, category, coffee_grams, milk_whole_ml || 0, notes || null);
  res.json(db.prepare('SELECT * FROM drink_recipes WHERE id=?').get(r.lastInsertRowid));
});

app.put('/api/recipes/:id', (req, res) => {
  const { square_item_name, category, coffee_grams, milk_whole_ml, notes } = req.body;
  db.prepare(`UPDATE drink_recipes SET square_item_name=?,category=?,coffee_grams=?,milk_whole_ml=?,notes=?,updated_at=datetime('now') WHERE id=?`)
    .run(square_item_name, category, coffee_grams, milk_whole_ml || 0, notes || null, req.params.id);
  res.json(db.prepare('SELECT * FROM drink_recipes WHERE id=?').get(req.params.id));
});

app.delete('/api/recipes/:id', (req, res) => { db.prepare('DELETE FROM drink_recipes WHERE id=?').run(req.params.id); res.json({ success: true }); });

// ─── Coffee Deliveries CRUD ───────────────────────────────────────────────────
app.get('/api/coffee-deliveries', (req, res) => res.json(db.prepare('SELECT * FROM coffee_deliveries ORDER BY delivery_date DESC').all()));

app.post('/api/coffee-deliveries', (req, res) => {
  const { delivery_date,
    espresso_lbs_received, espresso_lbs_onhand,
    drip_lbs_received,     drip_lbs_onhand,
    coldbrew_lbs_received, coldbrew_lbs_onhand,
    pourover_lbs_received, pourover_lbs_onhand,
    notes } = req.body;
  const r = db.prepare(`INSERT INTO coffee_deliveries
    (delivery_date, espresso_lbs_received, espresso_lbs_onhand, drip_lbs_received, drip_lbs_onhand,
     coldbrew_lbs_received, coldbrew_lbs_onhand, pourover_lbs_received, pourover_lbs_onhand, notes)
    VALUES (?,?,?,?,?,?,?,?,?,?)`)
    .run(delivery_date,
      espresso_lbs_received||0, espresso_lbs_onhand||0,
      drip_lbs_received||0,     drip_lbs_onhand||0,
      coldbrew_lbs_received||0, coldbrew_lbs_onhand||0,
      pourover_lbs_received||0, pourover_lbs_onhand||0,
      notes||null);
  res.json(db.prepare('SELECT * FROM coffee_deliveries WHERE id=?').get(r.lastInsertRowid));
});

app.delete('/api/coffee-deliveries/:id', (req, res) => { db.prepare('DELETE FROM coffee_deliveries WHERE id=?').run(req.params.id); res.json({ success: true }); });

// ─── Milk Deliveries CRUD ─────────────────────────────────────────────────────
app.get('/api/milk-deliveries', (req, res) => res.json(db.prepare('SELECT * FROM milk_deliveries ORDER BY delivery_date DESC').all()));

app.post('/api/milk-deliveries', (req, res) => {
  const { delivery_date, whole_bottles_received, whole_bottles_onhand, notes } = req.body;
  const r = db.prepare('INSERT INTO milk_deliveries (delivery_date,whole_bottles_received,whole_bottles_onhand,notes) VALUES (?,?,?,?)')
    .run(delivery_date, whole_bottles_received||0, whole_bottles_onhand||0, notes||null);
  res.json(db.prepare('SELECT * FROM milk_deliveries WHERE id=?').get(r.lastInsertRowid));
});

app.delete('/api/milk-deliveries/:id', (req, res) => { db.prepare('DELETE FROM milk_deliveries WHERE id=?').run(req.params.id); res.json({ success: true }); });

// ─── PDF Report ──────────────────────────────────────────────────────────────
app.post('/api/report', async (req, res) => {
  try {
    const { start_date, end_date } = req.body;
    if (!start_date || !end_date) return res.status(400).json({ error: 'start_date and end_date required' });

    // Reuse analytics logic
    const analyticsRes = await fetch(`http://localhost:${PORT}/api/analytics`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ start_date, end_date }),
    });
    const analytics = await analyticsRes.json();
    if (analytics.error) return res.status(500).json({ error: analytics.error });

    const coffeeDels = db.prepare(
      'SELECT * FROM coffee_deliveries WHERE delivery_date >= ? AND delivery_date <= ? ORDER BY delivery_date ASC'
    ).all(start_date, end_date);

    const milkDels = db.prepare(
      'SELECT * FROM milk_deliveries WHERE delivery_date >= ? AND delivery_date <= ? ORDER BY delivery_date ASC'
    ).all(start_date, end_date);

    const doc = generateReport({ analytics, coffeeDels, milkDels, startDate: start_date, endDate: end_date });

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="dose-report-${start_date}-${end_date}.pdf"`);
    doc.pipe(res);
    doc.end();
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

// ─── Seed recipes if empty ────────────────────────────────────────────────────
if (db.prepare('SELECT COUNT(*) as n FROM drink_recipes').get().n === 0) {
  const ins = db.prepare('INSERT INTO drink_recipes (square_item_name,category,coffee_grams,milk_whole_ml,notes) VALUES (?,?,?,?,?)');
  [
    ['Americano','espresso',18,0,'single'],
    ['Caffe Latte','espresso',18,240,'12oz'],
    ['Cappuccino','espresso',18,120,'6oz'],
    ['Cortado','espresso',18,60,''],
    ['Espresso','espresso',18,0,'all variations'],
    ['Espresso Macchiato','espresso',18,0,''],
    ['Extra Shot','espresso',18,0,''],
    ['Flat White','espresso',18,150,''],
    ['Batch Brew','drip',24.4,0,'110g / 4.5 cups'],
    ['Cafe Au Lait','drip',24.4,0,'pulls from batch brew stock'],
    ['Cold Brew','coldbrew',26.2,0,'4kg / 20x1.8L bottles, 8oz serve'],
    ['Pour Over','pourover',19,0,'single brew — all bean variations'],
    ['Turkish Coffee','pourover',7.5,0,'deducted from pour-over pool'],
  ].forEach(r => ins.run(...r));
  console.log('Seeded default recipes');
}

// ─── Serve frontend ───────────────────────────────────────────────────────────
if (process.env.NODE_ENV === 'production') {
  app.use(express.static(path.join(__dirname, '../frontend/build')));
  app.get('*', (req, res) => res.sendFile(path.join(__dirname, '../frontend/build/index.html')));
}

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => console.log(`Dose backend running on port ${PORT}`));
